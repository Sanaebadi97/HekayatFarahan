package info.sanaebadi.hekayatfarahan.db

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import info.sanaebadi.hekayatfarahan.model.Game
import info.sanaebadi.hekayatfarahan.repository.Repository

class ViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository =
        GameRepository(application)

    fun getGames() = repository.getGames()

    fun setGame(game: Game) {
        repository.setGame(game)
    }


    fun cancelJob() {
        Repository.cancelJob()
    }
}