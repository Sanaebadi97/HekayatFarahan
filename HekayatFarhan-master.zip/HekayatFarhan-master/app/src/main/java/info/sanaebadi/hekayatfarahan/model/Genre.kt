package info.sanaebadi.hekayatfarahan.model


data class Genre(
    val id: Int,
    val image: String,
    val name: String
)