package info.sanaebadi.hekayatfarahan.view.fragment


import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import info.sanaebadi.hekayatfarahan.R
import info.sanaebadi.hekayatfarahan.view.adapter.GameAdapter
import info.sanaebadi.hekayatfarahan.viewModel.GameViewModel
import info.sanaebadi.hekayatfarahan.db.ViewModel
import org.koin.android.viewmodel.ext.android.viewModel

/**
 * A simple [Fragment] subclass.
 */
class GameListHome : Fragment() {

    lateinit var gameAdapter: GameAdapter

    private val viewModel: GameViewModel by viewModel()
    //private val offlineViewModel: ViewModel by viewModel()
    lateinit var offlineViewModel: ViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_game_list_home, container, false)
        val rvGameList = view.findViewById<RecyclerView>(R.id.rv_game)
        val progressbar = view.findViewById<ProgressBar>(R.id.progressbar)


        offlineViewModel = ViewModelProvider(this).get(ViewModel::class.java)

        progressbar.visibility = View.VISIBLE

        viewModel.gemes.observe(viewLifecycleOwner, Observer { games ->
            println("GAMES $games")

            gameAdapter = GameAdapter(games)
            rvGameList.setHasFixedSize(true)
            rvGameList.layoutManager = GridLayoutManager(activity, 2)
            rvGameList.adapter = gameAdapter
            progressbar.visibility = View.GONE

        })


        //database data

        if (!hasNetwork(activity!!)!!) {
            offlineViewModel.getGames()!!.observe(viewLifecycleOwner, Observer { gamesEntity ->
                gameAdapter = GameAdapter(gamesEntity)
                rvGameList.setHasFixedSize(true)
                rvGameList.layoutManager = GridLayoutManager(activity, 2)
                rvGameList.adapter = gameAdapter
                progressbar.visibility = View.GONE
            })
        }
        return view
    }


    fun hasNetwork(context: Context): Boolean? {
        var isConnected: Boolean? = false // Initial Value
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: NetworkInfo? = connectivityManager.activeNetworkInfo
        if (activeNetwork != null && activeNetwork.isConnected)
            isConnected = true
        return isConnected
    }


    override fun onDestroy() {
        super.onDestroy()
        viewModel.cancelJob()
        offlineViewModel.cancelJob()
    }


}
