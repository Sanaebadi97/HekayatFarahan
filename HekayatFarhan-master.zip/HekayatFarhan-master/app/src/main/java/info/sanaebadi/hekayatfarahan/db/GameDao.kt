package info.sanaebadi.hekayatfarahan.db

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.Dao
import info.sanaebadi.hekayatfarahan.model.Game

@Dao
interface GameDao {

    @Query("SELECT * FROM game")
    fun getAllGame(): LiveData<List<Game>>

    @Insert
    fun insert(game: Game)

    @Update
    fun update(game: Game)

    @Delete
    fun delete(game: Game)
}