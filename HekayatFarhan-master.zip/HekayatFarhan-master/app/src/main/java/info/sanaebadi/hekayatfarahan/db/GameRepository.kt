package info.sanaebadi.hekayatfarahan.db

import android.app.Application
import info.sanaebadi.hekayatfarahan.model.Game
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

class GameRepository(application: Application) : CoroutineScope {

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main

    private var gameDao: GameDao

    init {
        val db = GameDatabase.getInstance(application)
        gameDao = db!!.gameDao()
    }

    fun getGames() = gameDao.getAllGame()

    fun setGame(game: Game) {
        launch {
            setGame(game)
        }
    }

    private suspend fun setGameBG(game: Game) {
        withContext(Dispatchers.IO) {
            gameDao.insert(game)
        }
    }
}