package info.sanaebadi.hekayatfarahan.model


import androidx.room.Entity
import com.google.gson.annotations.SerializedName

@Entity(tableName = "game")
data class Game(
    val description: String,
    val genre: Genre,
    val image: String,
    @SerializedName("players_count")
    val playersCount: Int,
    val rate: String,
    val title: String,
    val video: String
)